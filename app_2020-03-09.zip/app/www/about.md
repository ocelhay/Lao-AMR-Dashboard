<a href="http://www.tropmedres.ac/home" target="_blank"><img src="./MORU_logo.jpg" height = "90px" align = "left" border = 2/></a>

This app was developed by [Olivier Celhay](mailto:olivier.celhay@gmail.com). For any inquiry on this application, please contact [Vilada Chansamouth](mailto:Vilada@tropmedres.ac).

