## Disclaimer

The information contained in this application is the property of *Mahosod hospital/LOMWRU* and may not be reproduced or distributed in any manner without express written permission.

While *Mahosod hospital/LOMWRU* has attempted to ensure the accuracy of the data it is reporting, it makes no representations or warranties, expressed or implied, as to the accuracy or completeness of the information reported. Likewise, *Mahosod hospital/LOMWRU* makes no representations or warranties, expressed or implied, as to the accuracy of the comparative data provided herein. *Mahosod hospital/LOMWRU* assumes no legal liability or responsibility for any errors or omissions in the information or for any loss or damage resulting from the use of any information contained on these pages.

This report is not intended to provide medical advice.

PLEASE NOTE: This app may time-out if left idle too long, which will cause the screen to grey-out. To use the app again, refresh the page. This will reset all previously-selected input options.
